//
//  MiniGameApp.swift
//  MiniGame
//
//  Created by Johyeon Yoon on 2021/09/13.
//

import SwiftUI

@main
struct MiniGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
//            InformationView()
        }
    }
}
